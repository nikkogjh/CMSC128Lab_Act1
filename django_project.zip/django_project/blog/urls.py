from django.urls import path
from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    # if empty string after removing blog from blog.url
    # '' goes to blog.views.home
    path('', views.home, name='blog-home'),

    # use feedback() function from views.py to reroute and render feedback.html
    path('feedback/', views.feedback, name='blog-feedback'),
    
    # use contact() function from views.py to reroute and render contact.html
    path('contact/', views.contact, name='blog-contact'),

    path('kitchen/', views.kitchen, name='blog-kitchen'),

    path('farm/', views.farm, name='blog-farm'),
]

urlpatterns += staticfiles_urlpatterns()