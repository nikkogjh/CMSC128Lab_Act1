from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.db.models.fields import TextField

class Post(models.Model):
    title = models.CharField(max_length=255)
    content = models.TextField()
    date_posted = models.DateTimeField(default = timezone.now)
    #if user deleted, delete post
    author = models.ForeignKey(User, on_delete=models.CASCADE) 

    def __str__(self):
        return self.title

# USER FEEDBACK MODEL USED FOR "CONTACT ME" WEBPAGE
class Feedback(models.Model):
	# define the table columns based on "Contact Me" form
	name = models.CharField(max_length=100)
	email = models.CharField(max_length=100)
	message = TextField()
	# the date and time the user sent the message
	date = models.DateTimeField(auto_now_add=True)

	# Dunder str method for printing when querying
	def __str__(self):
		return self.name + "-" + self.email