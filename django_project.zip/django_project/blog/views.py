from django.shortcuts import render
from .models import Post
from .models import Feedback
from .forms import ContactForm

# posts  = [
#     {
#         'author': 'CoreyMS',
#         'title': 'Blog Post 1',
#         'content': 'First post content',
#         'date_posted': 'August 27, 2018'
#     },
#     {
#         'author': 'Jane Doe',
#         'title': 'Blog Post 2',
#         'content': 'Second post content',
#         'date_posted': 'August 28, 2018'
#     }
# ]



# Create your views here.
def home(request):
    context = {
        'posts': Post.objects.all(), #list of posts
        'title': 'Home'
    }
    return render(request, 'blog/home.html', context)

def farm(request):
    return render(request, 'blog/farm.html', {'title': 'The Farm'})

def kitchen(request):
    return render(request, 'blog/kitchen.html', {'title': 'The Kitchen'})

def feedback(request):
	context = {
		'feedbacks': Feedback.objects.all()
	}
	return render(request, 'blog/feedback.html', context)


# FUNCTION FOR CONTACT US PAGE and FORM SUBMISSION
def contact(request):
	if request.method == 'POST':
		name = request.POST.get('name')
		email = request.POST.get('email')
		message = request.POST.get('message')
		date = request.POST.get('date')
		form = ContactForm(request.POST) #name=name, email=email, message=message,date=date)
		form.save()
	return render(request, 'blog/contact.html')